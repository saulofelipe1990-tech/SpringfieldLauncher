# Springfield Launcher (HY300)

Launcher nativo, leve e sem dependências, com o seu wallpaper embutido.

## Navegação
- Setas + OK: abrir. **Segurar OK** num app: adiciona/remove dos favoritos.
- Linha SISTEMA: Play Store, Configurações, entradas HDMI (só aparecem se o sistema as listar), Todos os apps, Trocar launcher.
- Voltar fecha a lista de apps; o launcher ignora Voltar na tela inicial.

## Compilar (GitHub Actions)
1. Envie esta pasta para um repositório no GitHub.
2. Aba Actions > Build APK > aguarde > baixe o artefato `SpringfieldLauncher-apk`.

## Instalar
    adb connect IP_DO_PROJETOR:5555
    adb install -r app-debug.apk

Depois, aperte Home no controle e escolha "Springfield Launcher" > "Sempre".

## Voltar ao launcher original / desinstalar
- Configurações do Android > Apps > launcher padrão, ou use o botão "Trocar launcher".
- Ou: `adb shell pm uninstall br.com.meulauncher.springfield`
