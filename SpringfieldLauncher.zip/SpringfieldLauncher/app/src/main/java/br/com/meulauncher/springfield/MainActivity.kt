package br.com.meulauncher.springfield

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private class AppInfo(val pkg: String, val label: String, val icon: Drawable, val intent: Intent)

    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val yellow = Color.parseColor("#FFD90F")
    private val pink = Color.parseColor("#FF6FB5")
    private val bold = Typeface.create("sans-serif-black", Typeface.NORMAL)
    private val defaults = listOf(
        "com.google.android.youtube.tv", "com.google.android.youtube",
        "com.netflix.ninja", "com.netflix.mediaclient",
        "com.amazon.amazonvideo.livingroom", "com.disney.disneyplus"
    )

    private lateinit var prefs: SharedPreferences
    private lateinit var main: FrameLayout
    private lateinit var rows: LinearLayout
    private lateinit var overlay: FrameLayout
    private lateinit var grid: GridLayout
    private var apps: List<AppInfo> = emptyList()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun full() = FrameLayout.LayoutParams(match, match)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("launcher", Context.MODE_PRIVATE)

        val root = FrameLayout(this)
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.wallpaper)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, full())
        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(170, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(220, 8, 4, 20))
            )
        }, full())

        main = FrameLayout(this)
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(40), dp(20), 0, 0)
        }
        top.addView(TextClock(this).apply {
            format12Hour = "HH:mm"; format24Hour = "HH:mm"
            textSize = 60f; setTextColor(yellow); typeface = bold
            setShadowLayer(10f, 0f, 5f, Color.BLACK)
        })
        top.addView(TextClock(this).apply {
            format12Hour = "EEEE, d 'de' MMMM"; format24Hour = "EEEE, d 'de' MMMM"
            textSize = 20f; setTextColor(Color.WHITE); typeface = bold
            setShadowLayer(8f, 0f, 3f, Color.BLACK)
        })
        main.addView(top, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.START))

        rows = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(40), 0, dp(40), dp(16))
        }
        main.addView(rows, FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM))
        root.addView(main, full())

        overlay = FrameLayout(this).apply {
            visibility = View.GONE
            setBackgroundColor(Color.argb(240, 18, 8, 34))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(40), dp(20), dp(40), dp(20))
        }
        box.addView(title("TODOS OS APPS  -  segure OK para favoritar"))
        grid = GridLayout(this)
        box.addView(grid)
        overlay.addView(ScrollView(this).apply { addView(box) }, full())
        root.addView(overlay, full())

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        apps = loadApps()
        render()
        if (overlay.visibility != View.VISIBLE && currentFocus == null) main.requestFocus()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (overlay.visibility == View.VISIBLE) closeAll()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (overlay.visibility == View.VISIBLE) closeAll()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- dados ----------

    private fun loadApps(): List<AppInfo> {
        val pm = packageManager
        val seen = HashSet<String>()
        val out = ArrayList<AppInfo>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val q = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(q, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || !seen.add(pkg)) continue
                val li = Intent(Intent.ACTION_MAIN).addCategory(cat)
                    .setClassName(pkg, ri.activityInfo.name)
                out.add(AppInfo(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), li))
            }
        }
        return out.sortedBy { it.label.lowercase() }
    }

    private fun favs(): MutableList<String> {
        val raw = prefs.getString("fav", null)
        val list = if (raw == null) defaults.filter { p -> apps.any { it.pkg == p } }
        else raw.split(",").filter { it.isNotBlank() }
        return list.toMutableList()
    }

    private fun toggleFav(pkg: String) {
        val l = favs()
        val added = if (l.contains(pkg)) { l.remove(pkg); false } else { l.add(pkg); true }
        prefs.edit().putString("fav", l.joinToString(",")).apply()
        Toast.makeText(this, if (added) "Adicionado aos favoritos" else "Removido dos favoritos", Toast.LENGTH_SHORT).show()
        render()
    }

    private fun hdmiInputs(): List<Pair<String, Intent>> = try {
        val tm = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
        tm.tvInputList.filter { it.type == TvInputInfo.TYPE_HDMI }.map {
            val name = it.loadLabel(this)?.toString()?.takeIf { s -> s.isNotBlank() } ?: "HDMI"
            Pair(name, Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(it.id)))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun launch(i: Intent) {
        try {
            startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível abrir", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- telas ----------

    private fun render() {
        rows.removeAllViews()
        val byPkg = apps.associateBy { it.pkg }

        val fav = favs().mapNotNull { byPkg[it] }.map { a ->
            tile(a.label, a.icon, null, { launch(a.intent) }, { toggleFav(a.pkg) })
        }.toMutableList()
        if (fav.isEmpty()) fav.add(tile("Adicionar apps", null, "+", { openAll() }, null))
        rows.addView(title("FAVORITOS"))
        rows.addView(row(fav))

        val sys = ArrayList<View>()
        packageManager.getLaunchIntentForPackage("com.android.vending")?.let { i ->
            sys.add(tile("Play Store", byPkg["com.android.vending"]?.icon, ">", { launch(i) }, null))
        }
        sys.add(tile("Configurações", null, "⚙", { launch(Intent(Settings.ACTION_SETTINGS)) }, null))
        hdmiInputs().forEach { (name, intent) -> sys.add(tile(name, null, "▣", { launch(intent) }, null)) }
        sys.add(tile("Todos os apps", null, "▦", { openAll() }, null))
        sys.add(tile("Trocar launcher", null, "⌂", { launch(Intent(Settings.ACTION_HOME_SETTINGS)) }, null))
        rows.addView(title("SISTEMA"))
        rows.addView(row(sys))
    }

    private fun openAll() {
        grid.removeAllViews()
        val m = resources.displayMetrics
        grid.columnCount = maxOf(3, ((m.widthPixels / m.density - 80) / 116).toInt())
        apps.forEach { a ->
            val lp = GridLayout.LayoutParams()
            lp.width = dp(104); lp.height = wrap
            lp.setMargins(0, 0, dp(12), dp(12))
            grid.addView(tile(a.label, a.icon, null, { launch(a.intent) }, { toggleFav(a.pkg) }), lp)
        }
        overlay.visibility = View.VISIBLE
        main.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
        grid.getChildAt(0)?.requestFocus()
    }

    private fun closeAll() {
        overlay.visibility = View.GONE
        main.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        main.requestFocus()
    }

    // ---------- componentes ----------

    private fun title(s: String) = TextView(this).apply {
        text = s; textSize = 13f; typeface = bold; setTextColor(pink)
        letterSpacing = 0.1f
        setShadowLayer(6f, 0f, 2f, Color.BLACK)
        setPadding(dp(4), dp(8), 0, 0)
    }

    private fun row(tiles: List<View>): HorizontalScrollView {
        val h = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false; clipToPadding = false
            setPadding(0, dp(6), 0, dp(10))
        }
        val l = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; clipChildren = false }
        tiles.forEach { t ->
            l.addView(t, LinearLayout.LayoutParams(dp(104), wrap).apply { setMargins(0, 0, dp(12), 0) })
        }
        h.addView(l)
        return h
    }

    private fun shape(fill: Int, stroke: Int, w: Int) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(16).toFloat(); setStroke(dp(w), stroke)
    }

    private fun tile(
        label: String, icon: Drawable?, glyph: String?,
        onClick: () -> Unit, onLong: (() -> Unit)?
    ): View {
        val idle = shape(Color.argb(150, 20, 10, 40), Color.argb(70, 255, 255, 255), 1)
        val sel = shape(yellow, Color.WHITE, 3)
        val dark = Color.parseColor("#1B1B1B")

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(10), dp(6), dp(8))
            isFocusable = true; isClickable = true
            background = idle
        }
        val g: TextView? = if (icon == null) TextView(this).apply {
            text = glyph; textSize = 32f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        } else null
        if (icon != null) {
            box.addView(ImageView(this).apply { setImageDrawable(icon) }, LinearLayout.LayoutParams(dp(52), dp(52)))
        } else {
            box.addView(g, LinearLayout.LayoutParams(dp(52), dp(52)))
        }
        val t = TextView(this).apply {
            text = label; textSize = 12f; typeface = bold; setTextColor(Color.WHITE)
            maxLines = 1; ellipsize = TextUtils.TruncateAt.END; gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, 0)
        }
        box.addView(t, LinearLayout.LayoutParams(match, wrap))

        box.setOnClickListener { onClick() }
        if (onLong != null) box.setOnLongClickListener { onLong(); true }
        box.setOnFocusChangeListener { v, f ->
            v.background = if (f) sel else idle
            t.setTextColor(if (f) dark else Color.WHITE)
            g?.setTextColor(if (f) dark else Color.WHITE)
            val s = if (f) 1.1f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            v.translationZ = if (f) dp(8).toFloat() else 0f
        }
        return box
    }
}
